package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val OneUIDarkColorScheme = darkColorScheme(
    primary = OneUIBlue,
    onPrimary = Color.White,
    primaryContainer = OneUISurfaceVariant,
    onPrimaryContainer = OneUIBlueGlow,
    secondary = OneUICyan,
    onSecondary = Color.Black,
    secondaryContainer = OneUISurfaceElevated,
    onSecondaryContainer = OneUICyan,
    tertiary = OneUIPurple,
    onTertiary = Color.White,
    background = OneUIBackground,
    onBackground = OneUITextPrimary,
    surface = OneUISurface,
    onSurface = OneUITextPrimary,
    surfaceVariant = OneUISurfaceVariant,
    onSurfaceVariant = OneUITextSecondary,
    outline = OneUIBorder,
    outlineVariant = OneUIDivider,
    error = OneUIError,
    onError = Color.White,
    errorContainer = OneUIErrorContainer,
    onErrorContainer = OneUIError
)

@Composable
fun SifatAppLockTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OneUIDarkColorScheme,
        typography = Typography,
        content = content
    )
}
