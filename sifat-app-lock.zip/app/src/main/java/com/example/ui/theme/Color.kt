package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Samsung One UI Inspired Dark Palette
val OneUIBackground = Color(0xFF090D16)      // Deep midnight black
val OneUISurface = Color(0xFF131926)         // Slate card surface
val OneUISurfaceVariant = Color(0xFF1B2336)  // Elevated card/container
val OneUISurfaceElevated = Color(0xFF222C44) // Modal/dialog elevated surface

// Vibrant Accents
val OneUIBlue = Color(0xFF2E7BFA)            // Signature One UI electric blue
val OneUIBlueGlow = Color(0xFF5A9BFF)
val OneUICyan = Color(0xFF00C2FF)            // Secondary accent
val OneUIPurple = Color(0xFF8B5CF6)

// Functional Status
val OneUISuccess = Color(0xFF10B981)         // Shield active emerald
val OneUISuccessContainer = Color(0xFF063321)
val OneUIError = Color(0xFFFF453A)           // Intruder alert red
val OneUIErrorContainer = Color(0xFF381214)
val OneUIWarning = Color(0xFFFFB020)         // Permission required amber
val OneUIWarningContainer = Color(0xFF382300)

// Text & Icons
val OneUITextPrimary = Color(0xFFF3F5F9)     // High emphasis
val OneUITextSecondary = Color(0xFF94A3B8)   // Medium emphasis
val OneUITextMuted = Color(0xFF64748B)       // Low emphasis / hints
val OneUIBorder = Color(0xFF263249)          // Subtle card outline
val OneUIDivider = Color(0xFF1E293B)
val OneUIPinDotEmpty = Color(0xFF334155)
val OneUIPinDotFilled = Color(0xFF38BDF8)
