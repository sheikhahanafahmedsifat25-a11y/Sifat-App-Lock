package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppItem
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUISurface
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUISurfaceVariant
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary

@Composable
fun AppLockItem(
    app: AppItem,
    onToggleLock: (AppItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val lockContainerColor by animateColorAsState(
        targetValue = if (app.isLocked) OneUIBlue.copy(alpha = 0.14f) else OneUISurface,
        label = "item_bg"
    )

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(lockContainerColor)
            .clickable { onToggleLock(app) }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("app_lock_item_${app.packageName}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Icon
        AppIconRenderer(
            drawable = app.icon,
            fallbackLabel = app.appName,
            modifier = Modifier.size(46.dp)
        )

        Spacer(modifier = Modifier.width(14.dp))

        // App Details
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = app.appName,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = OneUITextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (app.isRecommended) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(OneUIBlue.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Sensitive",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = OneUIBlue
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(3.dp))

            Text(
                text = if (app.isLocked) "Protected with PIN & Fingerprint" else "Unlocked",
                fontSize = 12.sp,
                fontWeight = FontWeight.Normal,
                color = if (app.isLocked) OneUIBlue else OneUITextMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        // Lock Toggle Switch
        Switch(
            checked = app.isLocked,
            onCheckedChange = { onToggleLock(app) },
            thumbContent = {
                Icon(
                    imageVector = if (app.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = null,
                    modifier = Modifier.size(14.dp),
                    tint = if (app.isLocked) Color.White else OneUITextSecondary
                )
            },
            colors = SwitchDefaults.colors(
                checkedThumbColor = OneUIBlue,
                checkedTrackColor = OneUIBlue.copy(alpha = 0.35f),
                uncheckedThumbColor = OneUITextSecondary,
                uncheckedTrackColor = OneUISurfaceVariant
            ),
            modifier = Modifier.testTag("switch_${app.packageName}")
        )
    }
}

@Composable
fun AppIconRenderer(
    drawable: Drawable?,
    fallbackLabel: String,
    modifier: Modifier = Modifier
) {
    val bitmap = remember(drawable) {
        drawable?.toBitmapSafe(96, 96)
    }

    if (bitmap != null) {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = fallbackLabel,
            modifier = modifier.clip(RoundedCornerShape(12.dp))
        )
    } else {
        Box(
            modifier = modifier
                .clip(RoundedCornerShape(12.dp))
                .background(OneUISurfaceElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = fallbackLabel,
                tint = OneUIBlue,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

private fun Drawable.toBitmapSafe(width: Int, height: Int): Bitmap? {
    return try {
        if (this is BitmapDrawable && this.bitmap != null) {
            return this.bitmap
        }
        val w = if (intrinsicWidth > 0) intrinsicWidth else width
        val h = if (intrinsicHeight > 0) intrinsicHeight else height
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        setBounds(0, 0, canvas.width, canvas.height)
        draw(canvas)
        bitmap
    } catch (e: Exception) {
        null
    }
}
