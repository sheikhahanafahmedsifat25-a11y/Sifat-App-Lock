package com.example

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.example.biometrics.BiometricHelper
import com.example.service.AppLockForegroundService
import com.example.ui.lock.LockActivity
import com.example.ui.lock.LockScreenComposable
import com.example.ui.screens.AppListScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.IntruderLogsScreen
import com.example.ui.screens.PinSetupScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.SifatAppLockTheme
import kotlinx.coroutines.launch

enum class AppScreen {
    SETUP_PIN,
    MASTER_UNLOCK,
    DASHBOARD,
    APP_LIST,
    SETTINGS,
    INTRUDER_LOGS,
    TEST_LOCK_SIMULATION
}

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val app = SifatAppLockApplication.instance
        lifecycleScope.launch {
            app.repository.refreshInstalledApps()
        }

        setContent {
            SifatAppLockTheme {
                MainAppNavigation(
                    activity = this,
                    app = app
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val app = SifatAppLockApplication.instance
        if (app.securityPreferences.isServiceProtectionEnabled) {
            AppLockForegroundService.startService(this)
        }
    }
}

@Composable
fun MainAppNavigation(
    activity: FragmentActivity,
    app: SifatAppLockApplication
) {
    val securityPrefs = app.securityPreferences
    val repository = app.repository

    var currentScreen by remember {
        mutableStateOf(
            if (!securityPrefs.isPinSet()) {
                AppScreen.SETUP_PIN
            } else {
                AppScreen.MASTER_UNLOCK
            }
        )
    }

    // Auto-prompt biometric if on master unlock screen
    LaunchedEffect(currentScreen) {
        if (currentScreen == AppScreen.MASTER_UNLOCK &&
            securityPrefs.isBiometricEnabled &&
            BiometricHelper.isBiometricHardwareAvailable(activity)
        ) {
            BiometricHelper.showBiometricPrompt(
                activity = activity,
                title = "Unlock Sifat App Lock",
                subtitle = "Touch the fingerprint sensor to access dashboard",
                negativeButtonText = "Use PIN",
                onSuccess = {
                    currentScreen = AppScreen.DASHBOARD
                },
                onError = { _, _ -> },
                onFailed = {
                    Toast.makeText(activity, "Fingerprint not recognized", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    AnimatedContent(
        targetState = currentScreen,
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "screen_transition"
    ) { screen ->
        when (screen) {
            AppScreen.SETUP_PIN -> {
                PinSetupScreen(
                    securityPreferences = securityPrefs,
                    onSetupComplete = {
                        currentScreen = AppScreen.DASHBOARD
                    }
                )
            }

            AppScreen.MASTER_UNLOCK -> {
                LockScreenComposable(
                    targetAppName = "Sifat App Lock",
                    targetPackage = activity.packageName,
                    targetAppIcon = null,
                    securityPreferences = securityPrefs,
                    onUnlockSuccess = {
                        currentScreen = AppScreen.DASHBOARD
                    },
                    onBiometricRequested = {
                        BiometricHelper.showBiometricPrompt(
                            activity = activity,
                            title = "Unlock Sifat App Lock",
                            subtitle = "Verify your identity to open dashboard",
                            onSuccess = {
                                currentScreen = AppScreen.DASHBOARD
                            },
                            onError = { _, _ -> },
                            onFailed = {
                                Toast.makeText(activity, "Fingerprint not recognized", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    onDismissOrExit = {
                        activity.finish()
                    },
                    onIntruderAttemptRecorded = { failedCount ->
                        activity.lifecycleScope.launch {
                            repository.recordIntruderAttempt(activity.packageName, failedCount)
                        }
                    },
                    isSimulationMode = false
                )
            }

            AppScreen.DASHBOARD -> {
                DashboardScreen(
                    repository = repository,
                    onNavigateToAppSelection = { currentScreen = AppScreen.APP_LIST },
                    onNavigateToSettings = { currentScreen = AppScreen.SETTINGS },
                    onNavigateToIntruderLogs = { currentScreen = AppScreen.INTRUDER_LOGS },
                    onTestLockScreen = { currentScreen = AppScreen.TEST_LOCK_SIMULATION }
                )
            }

            AppScreen.APP_LIST -> {
                BackHandler { currentScreen = AppScreen.DASHBOARD }
                AppListScreen(
                    repository = repository,
                    onBackClick = { currentScreen = AppScreen.DASHBOARD }
                )
            }

            AppScreen.SETTINGS -> {
                BackHandler { currentScreen = AppScreen.DASHBOARD }
                SettingsScreen(
                    securityPreferences = securityPrefs,
                    onNavigateBack = { currentScreen = AppScreen.DASHBOARD },
                    onNavigateToIntruderLogs = { currentScreen = AppScreen.INTRUDER_LOGS }
                )
            }

            AppScreen.INTRUDER_LOGS -> {
                BackHandler { currentScreen = AppScreen.DASHBOARD }
                IntruderLogsScreen(
                    repository = repository,
                    onBackClick = { currentScreen = AppScreen.DASHBOARD }
                )
            }

            AppScreen.TEST_LOCK_SIMULATION -> {
                BackHandler { currentScreen = AppScreen.DASHBOARD }
                LockScreenComposable(
                    targetAppName = "Gallery (Interactive Test)",
                    targetPackage = "com.sec.android.gallery3d",
                    targetAppIcon = null,
                    securityPreferences = securityPrefs,
                    onUnlockSuccess = {
                        Toast.makeText(activity, "Unlocked successfully!", Toast.LENGTH_SHORT).show()
                        currentScreen = AppScreen.DASHBOARD
                    },
                    onBiometricRequested = {
                        BiometricHelper.showBiometricPrompt(
                            activity = activity,
                            title = "Unlock Gallery (Test Mode)",
                            subtitle = "Testing native BiometricPrompt fingerprint",
                            onSuccess = {
                                Toast.makeText(activity, "Biometric authentication successful!", Toast.LENGTH_SHORT).show()
                                currentScreen = AppScreen.DASHBOARD
                            },
                            onError = { _, err ->
                                Toast.makeText(activity, "Biometric: $err", Toast.LENGTH_SHORT).show()
                            },
                            onFailed = {
                                Toast.makeText(activity, "Fingerprint not recognized. Try PIN.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    },
                    onDismissOrExit = {
                        currentScreen = AppScreen.DASHBOARD
                    },
                    onIntruderAttemptRecorded = { failedCount ->
                        activity.lifecycleScope.launch {
                            repository.recordIntruderAttempt("com.sec.android.gallery3d", failedCount)
                        }
                    },
                    isSimulationMode = true
                )
            }
        }
    }
}
