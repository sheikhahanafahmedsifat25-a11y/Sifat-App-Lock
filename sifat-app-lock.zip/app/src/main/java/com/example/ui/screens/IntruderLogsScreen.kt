package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.IntruderLogEntity
import com.example.data.repository.AppLockRepository
import com.example.ui.components.OneUICard
import com.example.ui.components.OneUIHeader
import com.example.ui.theme.OneUIBackground
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUISuccess
import com.example.ui.theme.OneUISurface
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun IntruderLogsScreen(
    repository: AppLockRepository,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val logs by repository.intruderLogsFlow.collectAsState(initial = emptyList())
    val totalCount by repository.totalIntruderCountFlow.collectAsState(initial = 0)
    var showClearDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OneUIBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        OneUIHeader(
            title = "Intruder Alert",
            subtitle = "$totalCount unauthorized attempt events logged",
            onBackClick = onBackClick,
            trailingContent = {
                if (logs.isNotEmpty()) {
                    IconButton(
                        onClick = { showClearDialog = true },
                        modifier = Modifier.testTag("clear_intruder_logs_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Clear Logs",
                            tint = OneUITextSecondary
                        )
                    }
                }
            }
        )

        // Summary Alert Banner
        Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
            OneUICard(
                backgroundColor = if (totalCount > 0) OneUIError.copy(alpha = 0.12f) else OneUISuccess.copy(alpha = 0.12f),
                borderColor = if (totalCount > 0) OneUIError.copy(alpha = 0.35f) else OneUISuccess.copy(alpha = 0.35f)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (totalCount > 0) OneUIError.copy(alpha = 0.2f) else OneUISuccess.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (totalCount > 0) Icons.Default.Warning else Icons.Default.Security,
                            contentDescription = null,
                            tint = if (totalCount > 0) OneUIError else OneUISuccess,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (totalCount > 0) "$totalCount Intruder Alerts Recorded" else "No Intruders Detected",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = OneUITextPrimary
                        )
                        Text(
                            text = if (totalCount > 0)
                                "Wrong PIN attempts triggered temporary lockouts"
                            else
                                "Your protected applications are completely secure",
                            fontSize = 12.sp,
                            color = OneUITextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // History Log List
        if (logs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = null,
                        tint = OneUITextMuted,
                        modifier = Modifier.size(54.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Clean Security Log",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = OneUITextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Any unauthorized attempts with incorrect PINs will appear here with exact timestamps.",
                        fontSize = 13.sp,
                        color = OneUITextSecondary,
                        modifier = Modifier.padding(horizontal = 20.dp),
                        lineHeight = 18.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(logs, key = { it.id }) { log ->
                    IntruderLogCard(log = log)
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("Clear Intruder Logs?", color = OneUITextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text("All recorded attempt timestamps and history will be permanently deleted.", color = OneUITextSecondary) },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch { repository.clearIntruderLogs() }
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = OneUIError)
                ) {
                    Text("Clear All")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("Cancel", color = OneUIBlue)
                }
            },
            containerColor = OneUISurfaceElevated
        )
    }
}

@Composable
private fun IntruderLogCard(log: IntruderLogEntity) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, yyyy • hh:mm a", Locale.getDefault()) }
    val formattedDate = remember(log.timestamp) { dateFormat.format(Date(log.timestamp)) }

    OneUICard(
        backgroundColor = OneUISurface,
        cornerRadius = 16.dp,
        modifier = Modifier.testTag("intruder_log_${log.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(OneUIError.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = OneUIError,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${log.failedAttemptsCount} Failed Attempts on ${log.targetAppName}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = OneUITextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = log.targetPackageName,
                    fontSize = 11.sp,
                    color = OneUITextMuted
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = formattedDate,
                    fontSize = 11.sp,
                    color = OneUIError,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
