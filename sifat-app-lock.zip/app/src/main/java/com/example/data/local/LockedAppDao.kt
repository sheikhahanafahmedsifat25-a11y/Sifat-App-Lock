package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface LockedAppDao {

    @Query("SELECT * FROM locked_apps ORDER BY appName ASC")
    fun getAllLockedAppsFlow(): Flow<List<LockedAppEntity>>

    @Query("SELECT packageName FROM locked_apps WHERE isLocked = 1")
    fun getLockedPackageNamesFlow(): Flow<List<String>>

    @Query("SELECT packageName FROM locked_apps WHERE isLocked = 1")
    suspend fun getLockedPackageNames(): List<String>

    @Query("SELECT isLocked FROM locked_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun isAppLocked(packageName: String): Boolean?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(app: LockedAppEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(apps: List<LockedAppEntity>)

    @Query("UPDATE locked_apps SET isLocked = :isLocked, updatedAt = :timestamp WHERE packageName = :packageName")
    suspend fun setLocked(packageName: String, isLocked: Boolean, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE locked_apps SET isLocked = 0, updatedAt = :timestamp")
    suspend fun unlockAll(timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE locked_apps SET isLocked = 1, updatedAt = :timestamp WHERE isRecommended = 1")
    suspend fun lockAllRecommended(timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM locked_apps WHERE packageName = :packageName")
    suspend fun delete(packageName: String)
}
