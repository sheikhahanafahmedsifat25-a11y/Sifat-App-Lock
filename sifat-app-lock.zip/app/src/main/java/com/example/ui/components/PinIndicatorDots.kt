package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.keyframes
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUIPinDotEmpty
import kotlin.math.roundToInt

@Composable
fun PinIndicatorDots(
    pinLength: Int,
    maxDigits: Int = 6,
    isError: Boolean = false,
    modifier: Modifier = Modifier
) {
    val shakeOffset = remember { Animatable(0f) }

    LaunchedEffect(isError) {
        if (isError) {
            shakeOffset.snapTo(0f)
            shakeOffset.animateTo(
                targetValue = 0f,
                animationSpec = keyframes {
                    durationMillis = 400
                    0f at 0
                    -24f at 50
                    24f at 100
                    -18f at 150
                    18f at 200
                    -10f at 250
                    10f at 300
                    -4f at 350
                    0f at 400
                }
            )
        }
    }

    Row(
        modifier = modifier.offset { IntOffset(shakeOffset.value.roundToInt(), 0) },
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until maxDigits) {
            val isFilled = i < pinLength
            val dotColor = when {
                isError -> OneUIError
                isFilled -> OneUIBlue
                else -> OneUIPinDotEmpty
            }

            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(dotColor)
                    .then(
                        if (!isFilled && !isError) {
                            Modifier.border(1.5.dp, OneUIBlue.copy(alpha = 0.3f), CircleShape)
                        } else {
                            Modifier
                        }
                    )
            )
        }
    }
}
