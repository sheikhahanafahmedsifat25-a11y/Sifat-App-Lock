package com.example

import android.app.Application
import com.example.data.SecurityPreferences
import com.example.data.local.AppLockDatabase
import com.example.data.repository.AppLockRepository

class SifatAppLockApplication : Application() {

    lateinit var securityPreferences: SecurityPreferences
        private set

    lateinit var database: AppLockDatabase
        private set

    lateinit var repository: AppLockRepository
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        securityPreferences = SecurityPreferences(this)
        database = AppLockDatabase.getDatabase(this)
        repository = AppLockRepository(this, database, securityPreferences)
    }

    companion object {
        lateinit var instance: SifatAppLockApplication
            private set
    }
}
