package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom

enum class AutoLockDelay(val label: String, val seconds: Long) {
    IMMEDIATELY("Immediately on exit", 0L),
    AFTER_30_SECONDS("After 30 seconds", 30L),
    ON_SCREEN_OFF("When screen locks", -1L)
}

class SecurityPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )

    companion object {
        private const val PREFS_NAME = "sifat_applock_sec_prefs"
        private const val KEY_PIN_HASH = "key_pin_hash"
        private const val KEY_PIN_SALT = "key_pin_salt"
        private const val KEY_BIOMETRIC_ENABLED = "key_biometric_enabled"
        private const val KEY_SCRAMBLE_KEYPAD = "key_scramble_keypad"
        private const val KEY_AUTO_LOCK_DELAY = "key_auto_lock_delay"
        private const val KEY_MAX_INTRUDER_ATTEMPTS = "key_max_intruder_attempts"
        private const val KEY_LOCKOUT_UNTIL = "key_lockout_until"
        private const val KEY_SERVICE_ENABLED = "key_service_enabled"
        private const val KEY_FIRST_SETUP_COMPLETED = "key_first_setup_completed"
    }

    fun isPinSet(): Boolean {
        return prefs.getBoolean(KEY_FIRST_SETUP_COMPLETED, false) &&
                prefs.getString(KEY_PIN_HASH, null) != null
    }

    /**
     * Hashes the 6-digit PIN with a cryptographic salt using SHA-256 and stores both securely.
     */
    fun savePin(pin: String): Boolean {
        if (pin.length != 6 || !pin.all { it.isDigit() }) return false
        val salt = ByteArray(32)
        SecureRandom().nextBytes(salt)
        val hash = hashPin(pin, salt)

        prefs.edit()
            .putString(KEY_PIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_PIN_HASH, hash)
            .putBoolean(KEY_FIRST_SETUP_COMPLETED, true)
            .apply()
        return true
    }

    /**
     * Verifies the provided 6-digit PIN against the stored salted hash.
     */
    fun verifyPin(pin: String): Boolean {
        val storedHash = prefs.getString(KEY_PIN_HASH, null) ?: return false
        val storedSaltStr = prefs.getString(KEY_PIN_SALT, null) ?: return false
        val salt = Base64.decode(storedSaltStr, Base64.NO_WRAP)
        val computedHash = hashPin(pin, salt)
        return storedHash == computedHash
    }

    private fun hashPin(pin: String, salt: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(salt)
        val hashBytes = digest.digest(pin.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(hashBytes, Base64.NO_WRAP)
    }

    var isBiometricEnabled: Boolean
        get() = prefs.getBoolean(KEY_BIOMETRIC_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_BIOMETRIC_ENABLED, value).apply()

    var isScrambleKeypad: Boolean
        get() = prefs.getBoolean(KEY_SCRAMBLE_KEYPAD, false)
        set(value) = prefs.edit().putBoolean(KEY_SCRAMBLE_KEYPAD, value).apply()

    var autoLockDelay: AutoLockDelay
        get() {
            val name = prefs.getString(KEY_AUTO_LOCK_DELAY, AutoLockDelay.IMMEDIATELY.name)
            return try {
                AutoLockDelay.valueOf(name ?: AutoLockDelay.IMMEDIATELY.name)
            } catch (e: Exception) {
                AutoLockDelay.IMMEDIATELY
            }
        }
        set(value) = prefs.edit().putString(KEY_AUTO_LOCK_DELAY, value.name).apply()

    var maxIntruderAttempts: Int
        get() = prefs.getInt(KEY_MAX_INTRUDER_ATTEMPTS, 3)
        set(value) = prefs.edit().putInt(KEY_MAX_INTRUDER_ATTEMPTS, value).apply()

    var lockoutUntilTimestamp: Long
        get() = prefs.getLong(KEY_LOCKOUT_UNTIL, 0L)
        set(value) = prefs.edit().putLong(KEY_LOCKOUT_UNTIL, value).apply()

    fun isCurrentlyLockedOut(): Boolean {
        return System.currentTimeMillis() < lockoutUntilTimestamp
    }

    fun remainingLockoutSeconds(): Long {
        val diff = (lockoutUntilTimestamp - System.currentTimeMillis()) / 1000
        return if (diff > 0) diff else 0
    }

    fun setLockoutForSeconds(seconds: Long) {
        lockoutUntilTimestamp = System.currentTimeMillis() + (seconds * 1000)
    }

    fun clearLockout() {
        lockoutUntilTimestamp = 0L
    }

    var isServiceProtectionEnabled: Boolean
        get() = prefs.getBoolean(KEY_SERVICE_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SERVICE_ENABLED, value).apply()
}
