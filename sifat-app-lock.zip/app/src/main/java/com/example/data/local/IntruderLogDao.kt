package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface IntruderLogDao {

    @Query("SELECT * FROM intruder_logs ORDER BY timestamp DESC")
    fun getAllLogsFlow(): Flow<List<IntruderLogEntity>>

    @Query("SELECT COUNT(*) FROM intruder_logs")
    fun getLogsCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: IntruderLogEntity)

    @Query("DELETE FROM intruder_logs")
    suspend fun clearAll()
}
