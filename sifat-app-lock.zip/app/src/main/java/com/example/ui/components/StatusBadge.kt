package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUISuccess
import com.example.ui.theme.OneUIWarning

enum class BadgeType {
    ACTIVE,
    WARNING,
    ERROR,
    INFO
}

@Composable
fun StatusBadge(
    text: String,
    type: BadgeType = BadgeType.INFO,
    modifier: Modifier = Modifier
) {
    val (dotColor, bgColor, textColor) = when (type) {
        BadgeType.ACTIVE -> Triple(OneUISuccess, OneUISuccess.copy(alpha = 0.15f), OneUISuccess)
        BadgeType.WARNING -> Triple(OneUIWarning, OneUIWarning.copy(alpha = 0.15f), OneUIWarning)
        BadgeType.ERROR -> Triple(OneUIError, OneUIError.copy(alpha = 0.15f), OneUIError)
        BadgeType.INFO -> Triple(OneUIBlue, OneUIBlue.copy(alpha = 0.15f), OneUIBlue)
    }

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(bgColor)
            .padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Text(
            text = text,
            color = textColor,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
