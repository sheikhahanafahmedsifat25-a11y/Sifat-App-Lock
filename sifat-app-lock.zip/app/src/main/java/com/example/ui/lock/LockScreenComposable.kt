package com.example.ui.lock

import android.graphics.drawable.Drawable
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityPreferences
import com.example.ui.components.AppIconRenderer
import com.example.ui.components.OneUINumPad
import com.example.ui.components.PinIndicatorDots
import com.example.ui.theme.OneUIBackground
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun LockScreenComposable(
    targetAppName: String,
    targetPackage: String,
    targetAppIcon: Drawable?,
    securityPreferences: SecurityPreferences,
    onUnlockSuccess: () -> Unit,
    onBiometricRequested: () -> Unit,
    onDismissOrExit: () -> Unit,
    onIntruderAttemptRecorded: (failedCount: Int) -> Unit,
    isSimulationMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()

    var enteredPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var consecutiveFailedAttempts by remember { mutableIntStateOf(0) }
    var lockoutSecondsRemaining by remember { mutableLongStateOf(securityPreferences.remainingLockoutSeconds()) }

    // Lockout countdown timer
    LaunchedEffect(lockoutSecondsRemaining) {
        if (lockoutSecondsRemaining > 0) {
            delay(1000L)
            lockoutSecondsRemaining = securityPreferences.remainingLockoutSeconds()
        }
    }

    val isLockedOut = lockoutSecondsRemaining > 0

    fun checkPin(pin: String) {
        if (securityPreferences.verifyPin(pin)) {
            // Correct PIN!
            isError = false
            consecutiveFailedAttempts = 0
            securityPreferences.clearLockout()
            onUnlockSuccess()
        } else {
            // Wrong PIN
            isError = true
            consecutiveFailedAttempts += 1
            val maxAttempts = securityPreferences.maxIntruderAttempts

            if (consecutiveFailedAttempts >= maxAttempts) {
                // Trigger intruder lockout penalty (30 seconds)
                securityPreferences.setLockoutForSeconds(30L)
                lockoutSecondsRemaining = 30L
                onIntruderAttemptRecorded(consecutiveFailedAttempts)
                consecutiveFailedAttempts = 0
            }

            scope.launch {
                delay(600L)
                enteredPin = ""
                isError = false
            }
        }
    }

    fun handleDigit(d: String) {
        if (isLockedOut || isError) return
        if (enteredPin.length < 6) {
            val next = enteredPin + d
            enteredPin = next
            if (next.length == 6) {
                checkPin(next)
            }
        }
    }

    fun handleDelete() {
        if (isLockedOut || isError) return
        if (enteredPin.isNotEmpty()) {
            enteredPin = enteredPin.dropLast(1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OneUIBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top row with Simulation badge or Close button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isSimulationMode) {
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(OneUIBlue.copy(alpha = 0.2f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "Interactive Test Mode",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = OneUIBlue
                    )
                }
            } else {
                Spacer(modifier = Modifier.size(36.dp))
            }

            IconButton(
                onClick = onDismissOrExit,
                modifier = Modifier.testTag("lock_exit_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Exit to Home",
                    tint = OneUITextSecondary
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Target App Icon & Title
        AppIconRenderer(
            drawable = targetAppIcon,
            fallbackLabel = targetAppName,
            modifier = Modifier.size(72.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = targetAppName,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = OneUITextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Locked with Sifat App Lock",
            fontSize = 13.sp,
            color = OneUITextMuted,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(28.dp))

        // PIN Indicator Dots
        PinIndicatorDots(
            pinLength = enteredPin.length,
            maxDigits = 6,
            isError = isError,
            modifier = Modifier.testTag("lock_pin_dots")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Status message / lockout warning
        Box(
            modifier = Modifier.height(30.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isLockedOut) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = OneUIError, modifier = Modifier.size(16.dp))
                    Text(
                        text = "Too many attempts! Locked for ${lockoutSecondsRemaining}s",
                        color = OneUIError,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            } else if (isError) {
                Text(
                    text = "Incorrect PIN. Attempt ${consecutiveFailedAttempts} of ${securityPreferences.maxIntruderAttempts}",
                    color = OneUIError,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            } else {
                Text(
                    text = "Enter 6-digit master passcode",
                    color = OneUITextSecondary,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Dialpad with Biometric button
        OneUINumPad(
            onDigitClick = { handleDigit(it) },
            onDeleteClick = { handleDelete() },
            onBiometricClick = onBiometricRequested,
            showBiometricButton = securityPreferences.isBiometricEnabled,
            scrambleDigits = securityPreferences.isScrambleKeypad,
            enabled = !isLockedOut && !isError,
            modifier = Modifier
                .padding(bottom = 16.dp)
                .testTag("lock_numpad")
        )
    }
}
