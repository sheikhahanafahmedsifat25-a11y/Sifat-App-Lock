package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppItem
import com.example.data.repository.AppLockRepository
import com.example.ui.components.AppLockItem
import com.example.ui.components.OneUIHeader
import com.example.ui.theme.OneUIBackground
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIBorder
import com.example.ui.theme.OneUISurface
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUISurfaceVariant
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary
import kotlinx.coroutines.launch

enum class AppFilter {
    ALL,
    LOCKED,
    UNLOCKED,
    RECOMMENDED
}

@Composable
fun AppListScreen(
    repository: AppLockRepository,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val apps by repository.appsFlow.collectAsState(initial = emptyList())

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf(AppFilter.ALL) }

    val filteredApps = remember(apps, searchQuery, selectedFilter) {
        apps.filter { app ->
            val matchesSearch = searchQuery.isBlank() ||
                    app.appName.contains(searchQuery, ignoreCase = true) ||
                    app.packageName.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                AppFilter.ALL -> true
                AppFilter.LOCKED -> app.isLocked
                AppFilter.UNLOCKED -> !app.isLocked
                AppFilter.RECOMMENDED -> app.isRecommended
            }

            matchesSearch && matchesFilter
        }
    }

    val lockedCount = apps.count { it.isLocked }
    val recommendedCount = apps.count { it.isRecommended }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OneUIBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        // One UI Header
        OneUIHeader(
            title = "Choose Apps",
            subtitle = "$lockedCount of ${apps.size} apps protected",
            onBackClick = onBackClick
        )

        // Search Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text("Search installed applications...", color = OneUITextMuted, fontSize = 14.sp)
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search",
                        tint = OneUITextSecondary
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(
                                imageVector = Icons.Default.Clear,
                                contentDescription = "Clear search",
                                tint = OneUITextSecondary
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = OneUISurfaceVariant,
                    unfocusedContainerColor = OneUISurface,
                    focusedBorderColor = OneUIBlue,
                    unfocusedBorderColor = OneUIBorder,
                    focusedTextColor = OneUITextPrimary,
                    unfocusedTextColor = OneUITextPrimary
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("app_search_field")
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Filter Pills
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChipPill(
                    label = "All (${apps.size})",
                    isSelected = selectedFilter == AppFilter.ALL,
                    onClick = { selectedFilter = AppFilter.ALL },
                    testTag = "filter_all"
                )
            }
            item {
                FilterChipPill(
                    label = "Locked ($lockedCount)",
                    isSelected = selectedFilter == AppFilter.LOCKED,
                    onClick = { selectedFilter = AppFilter.LOCKED },
                    testTag = "filter_locked"
                )
            }
            item {
                FilterChipPill(
                    label = "Unlocked (${apps.size - lockedCount})",
                    isSelected = selectedFilter == AppFilter.UNLOCKED,
                    onClick = { selectedFilter = AppFilter.UNLOCKED },
                    testTag = "filter_unlocked"
                )
            }
            item {
                FilterChipPill(
                    label = "Sensitive ($recommendedCount)",
                    isSelected = selectedFilter == AppFilter.RECOMMENDED,
                    onClick = { selectedFilter = AppFilter.RECOMMENDED },
                    testTag = "filter_recommended"
                )
            }
        }

        // Quick Bulk Actions Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${filteredApps.size} apps found",
                fontSize = 12.sp,
                color = OneUITextMuted
            )

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "Lock Sensitive",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = OneUIBlue,
                    modifier = Modifier
                        .clickable {
                            scope.launch { repository.lockAllRecommended() }
                        }
                        .testTag("bulk_lock_sensitive")
                )
                Text(
                    text = "Unlock All",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = OneUITextSecondary,
                    modifier = Modifier
                        .clickable {
                            scope.launch { repository.unlockAll() }
                        }
                        .testTag("bulk_unlock_all")
                )
            }
        }

        // Apps List
        if (apps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = OneUIBlue, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Scanning installed applications...", color = OneUITextSecondary, fontSize = 14.sp)
                }
            }
        } else if (filteredApps.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = OneUITextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No apps matched your filter",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = OneUITextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Try clearing your search term or switching filter tabs.",
                        fontSize = 13.sp,
                        color = OneUITextSecondary
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filteredApps, key = { it.packageName }) { app ->
                    AppLockItem(
                        app = app,
                        onToggleLock = {
                            scope.launch { repository.toggleAppLock(it) }
                        }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun FilterChipPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) OneUIBlue else OneUISurfaceElevated)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else OneUITextSecondary,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
