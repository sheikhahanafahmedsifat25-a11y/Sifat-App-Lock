package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.biometrics.BiometricHelper
import com.example.data.repository.AppLockRepository
import com.example.service.AppLockForegroundService
import com.example.ui.components.AppLockItem
import com.example.ui.components.BadgeType
import com.example.ui.components.OneUICard
import com.example.ui.components.OneUIHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.OneUIBackground
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIBorder
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUISuccess
import com.example.ui.theme.OneUISurface
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUISurfaceVariant
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary
import com.example.ui.theme.OneUIWarning
import kotlinx.coroutines.launch

@Composable
fun DashboardScreen(
    repository: AppLockRepository,
    onNavigateToAppSelection: () -> Unit,
    onNavigateToSettings: () -> Unit,
    onNavigateToIntruderLogs: () -> Unit,
    onTestLockScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val lifecycleOwner = LocalLifecycleOwner.current

    val apps by repository.appsFlow.collectAsState(initial = emptyList())
    val lockedCount by repository.lockedAppsCountFlow.collectAsState(initial = 0)
    val intruderCount by repository.totalIntruderCountFlow.collectAsState(initial = 0)

    // Real-time permission tracking
    var hasUsageStats by remember { mutableStateOf(AppLockRepository.hasUsageStatsPermission(context)) }
    var hasOverlay by remember { mutableStateOf(AppLockRepository.hasOverlayPermission(context)) }
    var isServiceEnabled by remember { mutableStateOf(repository.securityPreferences.isServiceProtectionEnabled) }

    // Re-check permissions when returning from system settings
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasUsageStats = AppLockRepository.hasUsageStatsPermission(context)
                hasOverlay = AppLockRepository.hasOverlayPermission(context)
                isServiceEnabled = repository.securityPreferences.isServiceProtectionEnabled

                if (hasUsageStats && hasOverlay && isServiceEnabled) {
                    AppLockForegroundService.startService(context)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val isEnforcementFullyActive = hasUsageStats && hasOverlay && isServiceEnabled
    val biometricStatus = remember { BiometricHelper.getBiometricStatus(context) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OneUIBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // One UI Header
        item {
            OneUIHeader(
                title = "Sifat App Lock",
                subtitle = "Samsung One UI Protection Engine",
                onBackClick = null,
                trailingContent = {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        // Intruder Log Shortcut with badge
                        IconButton(
                            onClick = onNavigateToIntruderLogs,
                            modifier = Modifier.testTag("dashboard_intruder_button")
                        ) {
                            Box(contentAlignment = Alignment.TopEnd) {
                                Icon(
                                    imageVector = Icons.Default.Visibility,
                                    contentDescription = "Intruder Logs",
                                    tint = if (intruderCount > 0) OneUIError else OneUITextSecondary
                                )
                                if (intruderCount > 0) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(OneUIError)
                                    )
                                }
                            }
                        }

                        // Settings Icon
                        IconButton(
                            onClick = onNavigateToSettings,
                            modifier = Modifier.testTag("dashboard_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Security Settings",
                                tint = OneUITextPrimary
                            )
                        }
                    }
                }
            )
        }

        // Real Enforcement & Protection Shield Status Banner
        item {
            ProtectionStatusCard(
                isFullyActive = isEnforcementFullyActive,
                hasUsageStats = hasUsageStats,
                hasOverlay = hasOverlay,
                isServiceEnabled = isServiceEnabled,
                lockedCount = lockedCount,
                onToggleService = { enabled ->
                    isServiceEnabled = enabled
                    repository.securityPreferences.isServiceProtectionEnabled = enabled
                    if (enabled && hasUsageStats && hasOverlay) {
                        AppLockForegroundService.startService(context)
                    } else {
                        AppLockForegroundService.stopService(context)
                    }
                },
                onRequestUsageStats = {
                    val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
                    context.startActivity(intent)
                },
                onRequestOverlay = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    context.startActivity(intent)
                }
            )
        }

        // Quick Metrics Dashboard Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Metric 1: Locked Apps
                MetricCard(
                    title = "Protected",
                    value = "$lockedCount Apps",
                    icon = Icons.Default.Lock,
                    iconColor = OneUIBlue,
                    onClick = onNavigateToAppSelection,
                    modifier = Modifier.weight(1f).testTag("metric_protected_apps")
                )

                // Metric 2: Intruder Attempts
                MetricCard(
                    title = "Intruders",
                    value = "$intruderCount Events",
                    icon = Icons.Default.Visibility,
                    iconColor = if (intruderCount > 0) OneUIError else OneUITextSecondary,
                    onClick = onNavigateToIntruderLogs,
                    modifier = Modifier.weight(1f).testTag("metric_intruder_logs")
                )

                // Metric 3: Biometric Status
                MetricCard(
                    title = "Biometrics",
                    value = if (repository.securityPreferences.isBiometricEnabled && biometricStatus.isAvailable) "Active" else "PIN Only",
                    icon = Icons.Default.Fingerprint,
                    iconColor = if (repository.securityPreferences.isBiometricEnabled) OneUISuccess else OneUITextMuted,
                    onClick = onNavigateToSettings,
                    modifier = Modifier.weight(1f).testTag("metric_biometrics")
                )
            }
        }

        // Fast Action Buttons Card
        item {
            OneUICard(backgroundColor = OneUISurfaceVariant) {
                Text(
                    text = "Quick Actions",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = OneUITextPrimary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Test Lock Screen button
                    Button(
                        onClick = onTestLockScreen,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = OneUIBlue,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f).testTag("quick_test_lock_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Lock UI", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }

                    // Lock Recommended Apps button
                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                repository.lockAllRecommended()
                            }
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = OneUITextPrimary
                        ),
                        modifier = Modifier.weight(1f).testTag("quick_lock_sensitive_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = OneUIBlue
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Protect Sensitive", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // Top Protected Apps Section
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Protected Apps",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = OneUITextPrimary
                )

                Text(
                    text = "Select Apps",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = OneUIBlue,
                    modifier = Modifier
                        .clickable(onClick = onNavigateToAppSelection)
                        .testTag("dashboard_view_all_apps")
                )
            }
        }

        val topApps = apps.filter { it.isLocked }.take(6)
        if (topApps.isEmpty()) {
            item {
                OneUICard(
                    modifier = Modifier.testTag("empty_locked_apps_card"),
                    backgroundColor = OneUISurface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.LockOpen,
                            contentDescription = null,
                            tint = OneUITextMuted,
                            modifier = Modifier.size(44.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No Apps Protected Yet",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = OneUITextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Tap 'Select Apps' above to choose apps to lock with your 6-digit PIN and fingerprint.",
                            fontSize = 13.sp,
                            color = OneUITextSecondary,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Button(
                            onClick = onNavigateToAppSelection,
                            colors = ButtonDefaults.buttonColors(containerColor = OneUIBlue),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Choose Apps to Lock", fontSize = 13.sp)
                        }
                    }
                }
            }
        } else {
            items(topApps, key = { it.packageName }) { app ->
                AppLockItem(
                    app = app,
                    onToggleLock = {
                        scope.launch {
                            repository.toggleAppLock(it)
                        }
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun ProtectionStatusCard(
    isFullyActive: Boolean,
    hasUsageStats: Boolean,
    hasOverlay: Boolean,
    isServiceEnabled: Boolean,
    lockedCount: Int,
    onToggleService: (Boolean) -> Unit,
    onRequestUsageStats: () -> Unit,
    onRequestOverlay: () -> Unit
) {
    OneUICard(
        backgroundColor = if (isFullyActive) OneUISurfaceVariant else OneUISurface,
        borderColor = if (isFullyActive) OneUISuccess.copy(alpha = 0.4f) else OneUIWarning.copy(alpha = 0.5f),
        modifier = Modifier.testTag("protection_status_card")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(if (isFullyActive) OneUISuccess.copy(alpha = 0.15f) else OneUIWarning.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isFullyActive) Icons.Default.Security else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isFullyActive) OneUISuccess else OneUIWarning,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Column {
                    Text(
                        text = if (isFullyActive) "Protection Active" else "Permissions Required",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = OneUITextPrimary
                    )
                    Text(
                        text = if (isFullyActive) "$lockedCount apps shielded in real-time" else "Protection inactive without permissions",
                        fontSize = 13.sp,
                        color = if (isFullyActive) OneUISuccess else OneUIWarning
                    )
                }
            }

            if (hasUsageStats && hasOverlay) {
                Switch(
                    checked = isServiceEnabled,
                    onCheckedChange = onToggleService,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = OneUISuccess,
                        checkedTrackColor = OneUISuccess.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier.testTag("protection_service_switch")
                )
            }
        }

        // If permissions missing, show guided buttons
        AnimatedVisibility(visible = !hasUsageStats || !hasOverlay) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                Text(
                    text = "Android requires 2 special system permissions to detect when protected apps launch and display the lock screen:",
                    fontSize = 13.sp,
                    color = OneUITextSecondary,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Permission 1: Usage Access
                PermissionRowItem(
                    label = "Usage Access Permission",
                    description = "Required to detect when protected apps open",
                    isGranted = hasUsageStats,
                    onGrantClick = onRequestUsageStats,
                    testTag = "grant_usage_access_button"
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Permission 2: Display Over Other Apps
                PermissionRowItem(
                    label = "Appear on Top Permission",
                    description = "Required to display the PIN/Fingerprint lock screen",
                    isGranted = hasOverlay,
                    onGrantClick = onRequestOverlay,
                    testTag = "grant_overlay_button"
                )
            }
        }
    }
}

@Composable
private fun PermissionRowItem(
    label: String,
    description: String,
    isGranted: Boolean,
    onGrantClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(OneUISurfaceElevated)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = OneUITextPrimary)
            Text(text = description, fontSize = 11.sp, color = OneUITextMuted)
        }

        Spacer(modifier = Modifier.width(8.dp))

        if (isGranted) {
            StatusBadge(text = "Granted", type = BadgeType.ACTIVE)
        } else {
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = OneUIBlue),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.testTag(testTag)
            ) {
                Text("Grant", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OneUICard(
        modifier = modifier.clickable(onClick = onClick),
        backgroundColor = OneUISurface,
        cornerRadius = 18.dp
    ) {
        Column(modifier = Modifier.padding(2.dp)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = value,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = OneUITextPrimary,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                color = OneUITextSecondary
            )
        }
    }
}
