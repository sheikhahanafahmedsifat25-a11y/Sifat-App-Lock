package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.Password
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import com.example.biometrics.BiometricHelper
import com.example.biometrics.BiometricStatus
import com.example.data.AutoLockDelay
import com.example.data.SecurityPreferences
import com.example.ui.components.OneUICard
import com.example.ui.components.OneUIHeader
import com.example.ui.components.OneUINumPad
import com.example.ui.components.PinIndicatorDots
import com.example.ui.theme.OneUIBackground
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIBorder
import com.example.ui.theme.OneUIDivider
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUISuccess
import com.example.ui.theme.OneUISurface
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUISurfaceVariant
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary

enum class ChangePinStep {
    VERIFY_OLD,
    ENTER_NEW,
    CONFIRM_NEW
}

@Composable
fun SettingsScreen(
    securityPreferences: SecurityPreferences,
    onNavigateBack: () -> Unit,
    onNavigateToIntruderLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val biometricStatus = remember { BiometricHelper.getBiometricStatus(context) }

    var isBiometricEnabled by remember { mutableStateOf(securityPreferences.isBiometricEnabled) }
    var isScrambleKeypad by remember { mutableStateOf(securityPreferences.isScrambleKeypad) }
    var autoLockDelay by remember { mutableStateOf(securityPreferences.autoLockDelay) }
    var maxIntruderAttempts by remember { mutableIntStateOf(securityPreferences.maxIntruderAttempts) }

    // Dialog states
    var showChangePinDialog by remember { mutableStateOf(false) }
    var showAutoLockDialog by remember { mutableStateOf(false) }
    var showMaxAttemptsDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(OneUIBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            OneUIHeader(
                title = "Settings",
                subtitle = "Security & Protection Controls",
                onBackClick = onNavigateBack
            )
        }

        // Section 1: Authentication & PIN
        item {
            SectionTitle(title = "Authentication")
        }

        item {
            OneUICard {
                // Change 6-Digit PIN
                SettingsClickableRow(
                    icon = Icons.Default.Password,
                    title = "Change 6-Digit PIN",
                    subtitle = "Update your master lock passcode",
                    onClick = { showChangePinDialog = true },
                    testTag = "settings_change_pin"
                )

                HorizontalDivider(color = OneUIDivider, modifier = Modifier.padding(vertical = 12.dp))

                // Biometric Fingerprint Toggle
                SettingsSwitchRow(
                    icon = Icons.Default.Fingerprint,
                    title = "Fingerprint Unlock",
                    subtitle = when (biometricStatus) {
                        BiometricStatus.AVAILABLE -> "Touch sensor to unlock apps instantly"
                        BiometricStatus.NOT_ENROLLED -> "No fingerprint enrolled on device"
                        BiometricStatus.NO_HARDWARE -> "Biometric hardware not present"
                        else -> "Fingerprint sensor unavailable"
                    },
                    checked = isBiometricEnabled,
                    enabled = biometricStatus.isAvailable,
                    onCheckedChange = { checked ->
                        isBiometricEnabled = checked
                        securityPreferences.isBiometricEnabled = checked
                    },
                    testTag = "settings_toggle_biometric"
                )

                // Test Biometric Button if available
                if (biometricStatus.isAvailable && isBiometricEnabled) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            val activity = context as? FragmentActivity
                            if (activity != null) {
                                BiometricHelper.showBiometricPrompt(
                                    activity = activity,
                                    title = "Sifat App Lock Biometrics",
                                    subtitle = "Testing fingerprint sensor calibration",
                                    onSuccess = {
                                        Toast.makeText(context, "Fingerprint recognized successfully!", Toast.LENGTH_SHORT).show()
                                    },
                                    onError = { _, err ->
                                        Toast.makeText(context, "Biometric error: $err", Toast.LENGTH_SHORT).show()
                                    },
                                    onFailed = {
                                        Toast.makeText(context, "Fingerprint not recognized. Try again.", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = OneUISurfaceElevated),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().testTag("settings_test_biometric_button")
                    ) {
                        Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null, tint = OneUIBlue, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Test Fingerprint Sensor", fontSize = 12.sp, color = OneUITextPrimary)
                    }
                }
            }
        }

        // Section 2: Protection Behavior
        item {
            SectionTitle(title = "App Lock Behavior")
        }

        item {
            OneUICard {
                // Auto-Lock delay
                SettingsClickableRow(
                    icon = Icons.Default.Timer,
                    title = "Auto-Lock Policy",
                    subtitle = autoLockDelay.label,
                    onClick = { showAutoLockDialog = true },
                    testTag = "settings_auto_lock"
                )

                HorizontalDivider(color = OneUIDivider, modifier = Modifier.padding(vertical = 12.dp))

                // Scramble Keypad
                SettingsSwitchRow(
                    icon = Icons.Default.Shuffle,
                    title = "Scramble Keypad",
                    subtitle = "Randomize dialpad numbers to prevent shoulder-surfing",
                    checked = isScrambleKeypad,
                    onCheckedChange = { checked ->
                        isScrambleKeypad = checked
                        securityPreferences.isScrambleKeypad = checked
                    },
                    testTag = "settings_scramble_keypad"
                )
            }
        }

        // Section 3: Intruder Detection
        item {
            SectionTitle(title = "Intruder Alert")
        }

        item {
            OneUICard {
                // Max attempts threshold
                SettingsClickableRow(
                    icon = Icons.Default.LockClock,
                    title = "Max Failed Attempts",
                    subtitle = "Trigger alert and lockout after $maxIntruderAttempts wrong entries",
                    onClick = { showMaxAttemptsDialog = true },
                    testTag = "settings_max_attempts"
                )

                HorizontalDivider(color = OneUIDivider, modifier = Modifier.padding(vertical = 12.dp))

                // Intruder Logs
                SettingsClickableRow(
                    icon = Icons.Default.Visibility,
                    title = "View Intruder Logs",
                    subtitle = "Review unauthorized unlock attempts and timestamps",
                    onClick = onNavigateToIntruderLogs,
                    testTag = "settings_view_intruders"
                )
            }
        }

        // Section 4: Privacy & About
        item {
            SectionTitle(title = "Privacy & Encryption")
        }

        item {
            OneUICard(
                backgroundColor = OneUISurfaceVariant,
                onClick = { showPrivacyDialog = true }
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(OneUIBlue.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.PrivacyTip, contentDescription = null, tint = OneUIBlue, modifier = Modifier.size(20.dp))
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Zero-Cloud Local Privacy", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = OneUITextPrimary)
                        Text(text = "100% On-device encryption. Learn more.", fontSize = 12.sp, color = OneUITextSecondary)
                    }
                    Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = OneUITextMuted, modifier = Modifier.size(18.dp))
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Change PIN Dialog / Sheet
    if (showChangePinDialog) {
        ChangePinDialog(
            securityPreferences = securityPreferences,
            onDismiss = { showChangePinDialog = false },
            onSuccess = {
                showChangePinDialog = false
                Toast.makeText(context, "6-Digit PIN updated successfully!", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Auto-Lock Delay Dialog
    if (showAutoLockDialog) {
        AlertDialog(
            onDismissRequest = { showAutoLockDialog = false },
            title = { Text("Auto-Lock Delay", color = OneUITextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    AutoLockDelay.values().forEach { option ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    autoLockDelay = option
                                    securityPreferences.autoLockDelay = option
                                    showAutoLockDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = autoLockDelay == option,
                                onClick = {
                                    autoLockDelay = option
                                    securityPreferences.autoLockDelay = option
                                    showAutoLockDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = OneUIBlue)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = option.label, color = OneUITextPrimary, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAutoLockDialog = false }) {
                    Text("Cancel", color = OneUIBlue)
                }
            },
            containerColor = OneUISurfaceElevated
        )
    }

    // Max Attempts Dialog
    if (showMaxAttemptsDialog) {
        AlertDialog(
            onDismissRequest = { showMaxAttemptsDialog = false },
            title = { Text("Max Failed Attempts", color = OneUITextPrimary, fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    listOf(3, 5, 10).forEach { limit ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    maxIntruderAttempts = limit
                                    securityPreferences.maxIntruderAttempts = limit
                                    showMaxAttemptsDialog = false
                                }
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = maxIntruderAttempts == limit,
                                onClick = {
                                    maxIntruderAttempts = limit
                                    securityPreferences.maxIntruderAttempts = limit
                                    showMaxAttemptsDialog = false
                                },
                                colors = RadioButtonDefaults.colors(selectedColor = OneUIBlue)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "$limit wrong attempts", color = OneUITextPrimary, fontSize = 14.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showMaxAttemptsDialog = false }) {
                    Text("Cancel", color = OneUIBlue)
                }
            },
            containerColor = OneUISurfaceElevated
        )
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = OneUIBlue, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Privacy & Security", color = OneUITextPrimary, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "• Zero Network Calls: Sifat App Lock operates 100% offline. No internet permissions are used, so your data cannot leave your phone.",
                        color = OneUITextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Text(
                        text = "• Salted SHA-256: Your 6-digit PIN is never stored in plaintext. It is cryptographically salted with a 32-byte secure random seed.",
                        color = OneUITextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    Text(
                        text = "• Native BiometricPrompt: Fingerprint verification runs strictly inside Android's secure hardware enclave (TEE/Keystore).",
                        color = OneUITextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { showPrivacyDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = OneUIBlue)
                ) {
                    Text("Got It")
                }
            },
            containerColor = OneUISurfaceElevated
        )
    }
}

@Composable
private fun SectionTitle(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = OneUIBlue,
        letterSpacing = 0.8.sp,
        modifier = Modifier.padding(start = 4.dp, top = 4.dp)
    )
}

@Composable
private fun SettingsClickableRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp)
            .testTag(testTag),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(OneUISurfaceElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = OneUIBlue, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = OneUITextPrimary)
            Text(text = subtitle, fontSize = 12.sp, color = OneUITextSecondary)
        }

        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, tint = OneUITextMuted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun SettingsSwitchRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    enabled: Boolean = true,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(OneUISurfaceElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = if (enabled) OneUIBlue else OneUITextMuted, modifier = Modifier.size(20.dp))
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = if (enabled) OneUITextPrimary else OneUITextMuted)
            Text(text = subtitle, fontSize = 12.sp, color = OneUITextSecondary)
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = OneUIBlue,
                checkedTrackColor = OneUIBlue.copy(alpha = 0.35f)
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}

@Composable
private fun ChangePinDialog(
    securityPreferences: SecurityPreferences,
    onDismiss: () -> Unit,
    onSuccess: () -> Unit
) {
    var step by remember { mutableStateOf(ChangePinStep.VERIFY_OLD) }
    var enteredOldPin by remember { mutableStateOf("") }
    var enteredNewPin by remember { mutableStateOf("") }
    var enteredConfirmPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    val activeDigits = when (step) {
        ChangePinStep.VERIFY_OLD -> enteredOldPin
        ChangePinStep.ENTER_NEW -> enteredNewPin
        ChangePinStep.CONFIRM_NEW -> enteredConfirmPin
    }

    fun handleDigit(d: String) {
        if (isError) {
            isError = false
            errorText = null
        }

        when (step) {
            ChangePinStep.VERIFY_OLD -> {
                if (enteredOldPin.length < 6) {
                    val next = enteredOldPin + d
                    enteredOldPin = next
                    if (next.length == 6) {
                        if (securityPreferences.verifyPin(next)) {
                            step = ChangePinStep.ENTER_NEW
                        } else {
                            isError = true
                            errorText = "Incorrect current PIN"
                            enteredOldPin = ""
                        }
                    }
                }
            }
            ChangePinStep.ENTER_NEW -> {
                if (enteredNewPin.length < 6) {
                    val next = enteredNewPin + d
                    enteredNewPin = next
                    if (next.length == 6) {
                        step = ChangePinStep.CONFIRM_NEW
                    }
                }
            }
            ChangePinStep.CONFIRM_NEW -> {
                if (enteredConfirmPin.length < 6) {
                    val next = enteredConfirmPin + d
                    enteredConfirmPin = next
                    if (next.length == 6) {
                        if (next == enteredNewPin) {
                            securityPreferences.savePin(next)
                            onSuccess()
                        } else {
                            isError = true
                            errorText = "New PINs do not match"
                            enteredConfirmPin = ""
                        }
                    }
                }
            }
        }
    }

    fun handleDelete() {
        if (isError) return
        when (step) {
            ChangePinStep.VERIFY_OLD -> if (enteredOldPin.isNotEmpty()) enteredOldPin = enteredOldPin.dropLast(1)
            ChangePinStep.ENTER_NEW -> if (enteredNewPin.isNotEmpty()) enteredNewPin = enteredNewPin.dropLast(1)
            ChangePinStep.CONFIRM_NEW -> if (enteredConfirmPin.isNotEmpty()) enteredConfirmPin = enteredConfirmPin.dropLast(1)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = when (step) {
                    ChangePinStep.VERIFY_OLD -> "Verify Current PIN"
                    ChangePinStep.ENTER_NEW -> "Enter New 6-Digit PIN"
                    ChangePinStep.CONFIRM_NEW -> "Confirm New 6-Digit PIN"
                },
                color = OneUITextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = when (step) {
                        ChangePinStep.VERIFY_OLD -> "Enter your current 6-digit PIN to authorize change"
                        ChangePinStep.ENTER_NEW -> "Choose a new 6-digit master passcode"
                        ChangePinStep.CONFIRM_NEW -> "Re-enter the new 6-digit passcode to confirm"
                    },
                    color = OneUITextSecondary,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(18.dp))

                PinIndicatorDots(
                    pinLength = activeDigits.length,
                    maxDigits = 6,
                    isError = isError
                )

                if (errorText != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = errorText ?: "", color = OneUIError, fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(18.dp))

                OneUINumPad(
                    onDigitClick = { handleDigit(it) },
                    onDeleteClick = { handleDelete() },
                    showBiometricButton = false,
                    scrambleDigits = false,
                    enabled = !isError
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = OneUIBlue)
            }
        },
        containerColor = OneUISurfaceElevated
    )
}
