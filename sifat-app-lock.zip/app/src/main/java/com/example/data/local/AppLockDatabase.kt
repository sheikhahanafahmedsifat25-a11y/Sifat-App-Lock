package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [LockedAppEntity::class, IntruderLogEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppLockDatabase : RoomDatabase() {

    abstract fun lockedAppDao(): LockedAppDao
    abstract fun intruderLogDao(): IntruderLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppLockDatabase? = null

        fun getDatabase(context: Context): AppLockDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppLockDatabase::class.java,
                    "sifat_applock_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
