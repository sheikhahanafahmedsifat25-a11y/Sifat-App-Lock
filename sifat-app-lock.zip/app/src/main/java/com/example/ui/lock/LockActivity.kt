package com.example.ui.lock

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.lifecycleScope
import com.example.SifatAppLockApplication
import com.example.biometrics.BiometricHelper
import com.example.ui.theme.SifatAppLockTheme
import kotlinx.coroutines.launch

class LockActivity : FragmentActivity() {

    private var targetPackage: String = ""
    private var targetAppName: String = "Protected Application"
    private var targetAppIcon: Drawable? = null
    private var isSimulation: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE) ?: packageName
        isSimulation = intent.getBooleanExtra(EXTRA_IS_SIMULATION, false) || targetPackage == packageName

        resolveTargetAppInfo()

        setContent {
            SifatAppLockTheme {
                val app = SifatAppLockApplication.instance
                LockScreenComposable(
                    targetAppName = targetAppName,
                    targetPackage = targetPackage,
                    targetAppIcon = targetAppIcon,
                    securityPreferences = app.securityPreferences,
                    onUnlockSuccess = {
                        app.repository.markAppTemporarilyUnlocked(targetPackage)
                        finish()
                    },
                    onBiometricRequested = {
                        requestBiometricPrompt()
                    },
                    onDismissOrExit = {
                        exitToHomeOrFinish()
                    },
                    onIntruderAttemptRecorded = { failedCount ->
                        lifecycleScope.launch {
                            app.repository.recordIntruderAttempt(targetPackage, failedCount)
                        }
                    },
                    isSimulationMode = isSimulation
                )
            }
        }

        // Auto-prompt biometric if enabled and hardware is available
        val securityPrefs = SifatAppLockApplication.instance.securityPreferences
        if (securityPrefs.isBiometricEnabled && BiometricHelper.isBiometricHardwareAvailable(this)) {
            requestBiometricPrompt()
        }
    }

    private fun resolveTargetAppInfo() {
        try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(targetPackage, 0)
            targetAppName = pm.getApplicationLabel(appInfo).toString()
            targetAppIcon = pm.getApplicationIcon(appInfo)
        } catch (e: Exception) {
            targetAppName = if (isSimulation) "Gallery (Test App)" else "Protected App"
            targetAppIcon = null
        }
    }

    private fun requestBiometricPrompt() {
        BiometricHelper.showBiometricPrompt(
            activity = this,
            title = "Unlock $targetAppName",
            subtitle = "Touch the fingerprint sensor to continue",
            negativeButtonText = "Use 6-Digit PIN",
            onSuccess = {
                val app = SifatAppLockApplication.instance
                app.repository.markAppTemporarilyUnlocked(targetPackage)
                Toast.makeText(this, "Unlocked with Fingerprint", Toast.LENGTH_SHORT).show()
                finish()
            },
            onError = { errorCode, errString ->
                // User clicked "Use PIN" or cancelled
            },
            onFailed = {
                Toast.makeText(this, "Fingerprint not recognized. Please try again or use PIN.", Toast.LENGTH_SHORT).show()
            }
        )
    }

    private fun exitToHomeOrFinish() {
        if (isSimulation) {
            finish()
        } else {
            // Prevent accessing the protected app beneath by redirecting to Home launcher
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
            finish()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        exitToHomeOrFinish()
    }

    override fun onStart() {
        super.onStart()
        isLockScreenShowing = true
    }

    override fun onStop() {
        super.onStop()
        isLockScreenShowing = false
    }

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
        const val EXTRA_IS_SIMULATION = "extra_is_simulation"

        @Volatile
        var isLockScreenShowing: Boolean = false
    }
}
