package com.example.data.repository

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import com.example.data.AutoLockDelay
import com.example.data.SecurityPreferences
import com.example.data.local.AppLockDatabase
import com.example.data.local.IntruderLogEntity
import com.example.data.local.LockedAppEntity
import com.example.data.model.AppItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

class AppLockRepository(
    private val context: Context,
    private val database: AppLockDatabase,
    val securityPreferences: SecurityPreferences
) {
    private val lockedAppDao = database.lockedAppDao()
    private val intruderLogDao = database.intruderLogDao()

    // Temporary unlock cache: maps packageName to unlock timestamp (System.currentTimeMillis())
    private val temporarilyUnlockedApps = ConcurrentHashMap<String, Long>()
    private var lastActiveProtectedPackage: String? = null
    private var leftActivePackageTimestamp: Long = 0L

    private val _rawInstalledApps = MutableStateFlow<List<AppItem>>(emptyList())
    val rawInstalledApps = _rawInstalledApps.asStateFlow()

    // Combined stream of installed apps with their real-time locked status from Room DB
    val appsFlow: Flow<List<AppItem>> = combine(
        _rawInstalledApps,
        lockedAppDao.getAllLockedAppsFlow()
    ) { installed, lockedEntities ->
        val lockedMap = lockedEntities.associateBy { it.packageName }
        installed.map { app ->
            val entity = lockedMap[app.packageName]
            app.copy(
                isLocked = entity?.isLocked ?: false,
                isRecommended = app.isRecommended || (entity?.isRecommended ?: false)
            )
        }
    }

    val lockedAppsCountFlow: Flow<Int> = lockedAppDao.getAllLockedAppsFlow().map { entities ->
        entities.count { it.isLocked }
    }

    val intruderLogsFlow: Flow<List<IntruderLogEntity>> = intruderLogDao.getAllLogsFlow()
    val totalIntruderCountFlow: Flow<Int> = intruderLogDao.getLogsCountFlow()

    suspend fun refreshInstalledApps() = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }

        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        val myPackageName = context.packageName

        val existingDbRecords = lockedAppDao.getLockedPackageNames().toSet()

        val sensitiveKeywords = listOf(
            "gallery", "photo", "image", "message", "sms", "chat", "mail", "gmail",
            "setting", "camera", "bank", "pay", "wallet", "crypto", "contact",
            "file", "drive", "note", "auth", "whatsapp", "telegram", "facebook",
            "instagram", "snapchat", "tiktok", "twitter", "x.com", "signal"
        )

        val items = resolveInfos
            .mapNotNull { it.activityInfo?.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != myPackageName }
            .map { appInfo ->
                val appName = try {
                    pm.getApplicationLabel(appInfo).toString()
                } catch (e: Exception) {
                    appInfo.packageName
                }
                val icon = try {
                    pm.getApplicationIcon(appInfo)
                } catch (e: Exception) {
                    null
                }
                val isSystem = (appInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0
                val isRecommended = sensitiveKeywords.any {
                    appName.contains(it, ignoreCase = true) || appInfo.packageName.contains(it, ignoreCase = true)
                }

                AppItem(
                    packageName = appInfo.packageName,
                    appName = appName,
                    icon = icon,
                    isSystemApp = isSystem,
                    isLocked = existingDbRecords.contains(appInfo.packageName),
                    isRecommended = isRecommended
                )
            }
            .sortedWith(compareBy({ !it.isRecommended }, { it.appName.lowercase() }))

        _rawInstalledApps.value = items

        // Pre-populate DB with known items if needed
        val toInsert = items.map {
            LockedAppEntity(
                packageName = it.packageName,
                appName = it.appName,
                isLocked = existingDbRecords.contains(it.packageName),
                isRecommended = it.isRecommended
            )
        }
        lockedAppDao.insertAll(toInsert)
    }

    suspend fun toggleAppLock(app: AppItem) = withContext(Dispatchers.IO) {
        val newLockedState = !app.isLocked
        lockedAppDao.insertOrUpdate(
            LockedAppEntity(
                packageName = app.packageName,
                appName = app.appName,
                isLocked = newLockedState,
                isRecommended = app.isRecommended
            )
        )
        if (!newLockedState) {
            temporarilyUnlockedApps.remove(app.packageName)
        }
    }

    suspend fun lockAllRecommended() = withContext(Dispatchers.IO) {
        lockedAppDao.lockAllRecommended()
    }

    suspend fun unlockAll() = withContext(Dispatchers.IO) {
        lockedAppDao.unlockAll()
        temporarilyUnlockedApps.clear()
    }

    fun markAppTemporarilyUnlocked(packageName: String) {
        temporarilyUnlockedApps[packageName] = System.currentTimeMillis()
        lastActiveProtectedPackage = packageName
    }

    fun isAppTemporarilyUnlocked(packageName: String): Boolean {
        val unlockTime = temporarilyUnlockedApps[packageName] ?: return false
        val delay = securityPreferences.autoLockDelay
        return when (delay) {
            AutoLockDelay.IMMEDIATELY -> {
                // If it is the active app in foreground, valid until exited
                packageName == lastActiveProtectedPackage
            }
            AutoLockDelay.AFTER_30_SECONDS -> {
                val now = System.currentTimeMillis()
                (now - unlockTime) < 30_000L
            }
            AutoLockDelay.ON_SCREEN_OFF -> true
        }
    }

    fun notifyForegroundPackageChanged(newForegroundPackage: String) {
        if (newForegroundPackage == context.packageName) return

        if (lastActiveProtectedPackage != null && newForegroundPackage != lastActiveProtectedPackage) {
            // User left the protected app
            when (securityPreferences.autoLockDelay) {
                AutoLockDelay.IMMEDIATELY -> {
                    temporarilyUnlockedApps.remove(lastActiveProtectedPackage)
                }
                AutoLockDelay.AFTER_30_SECONDS -> {
                    leftActivePackageTimestamp = System.currentTimeMillis()
                }
                AutoLockDelay.ON_SCREEN_OFF -> {
                    // Stays unlocked until screen off or explicit relock
                }
            }
        }
        lastActiveProtectedPackage = newForegroundPackage
    }

    fun onScreenTurnedOff() {
        if (securityPreferences.autoLockDelay == AutoLockDelay.ON_SCREEN_OFF) {
            temporarilyUnlockedApps.clear()
        }
    }

    suspend fun isPackageLocked(packageName: String): Boolean = withContext(Dispatchers.IO) {
        if (packageName == context.packageName) return@withContext false
        val isLocked = lockedAppDao.isAppLocked(packageName) ?: false
        if (!isLocked) return@withContext false
        !isAppTemporarilyUnlocked(packageName)
    }

    suspend fun recordIntruderAttempt(targetPackage: String, count: Int) = withContext(Dispatchers.IO) {
        val appName = try {
            val pm = context.packageManager
            val info = pm.getApplicationInfo(targetPackage, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            targetPackage
        }

        intruderLogDao.insert(
            IntruderLogEntity(
                timestamp = System.currentTimeMillis(),
                targetPackageName = targetPackage,
                targetAppName = appName,
                failedAttemptsCount = count
            )
        )
    }

    suspend fun clearIntruderLogs() = withContext(Dispatchers.IO) {
        intruderLogDao.clearAll()
    }

    // Permission detection helpers
    companion object {
        fun hasUsageStatsPermission(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }

        fun hasOverlayPermission(context: Context): Boolean {
            return Settings.canDrawOverlays(context)
        }

        fun isProtectionActive(context: Context, prefs: SecurityPreferences): Boolean {
            return prefs.isServiceProtectionEnabled &&
                    hasUsageStatsPermission(context) &&
                    hasOverlayPermission(context)
        }
    }
}
