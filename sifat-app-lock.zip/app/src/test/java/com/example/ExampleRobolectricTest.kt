package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.SecurityPreferences
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Sifat App Lock", appName)
  }

  @Test
  fun `verify pin security preferences hashing`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val prefs = SecurityPreferences(context)
    val testPin = "123456"

    assertTrue(prefs.savePin(testPin))
    assertTrue(prefs.isPinSet())
    assertTrue(prefs.verifyPin(testPin))
    assertFalse(prefs.verifyPin("654321"))
    assertFalse(prefs.verifyPin("000000"))
  }
}
