package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SecurityPreferences
import com.example.ui.components.OneUINumPad
import com.example.ui.components.PinIndicatorDots
import com.example.ui.theme.OneUIBackground
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUIError
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class PinSetupStage {
    CREATE,
    CONFIRM
}

@Composable
fun PinSetupScreen(
    securityPreferences: SecurityPreferences,
    onSetupComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var stage by remember { mutableStateOf(PinSetupStage.CREATE) }
    var firstPin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    val currentEnteredPin = if (stage == PinSetupStage.CREATE) firstPin else confirmPin

    fun handleDigit(digit: String) {
        if (isError) {
            isError = false
            errorMessage = null
        }

        if (stage == PinSetupStage.CREATE) {
            if (firstPin.length < 6) {
                val newPin = firstPin + digit
                firstPin = newPin
                if (newPin.length == 6) {
                    scope.launch {
                        delay(250)
                        stage = PinSetupStage.CONFIRM
                    }
                }
            }
        } else {
            if (confirmPin.length < 6) {
                val newPin = confirmPin + digit
                confirmPin = newPin
                if (newPin.length == 6) {
                    if (newPin == firstPin) {
                        // Success! Save PIN
                        securityPreferences.savePin(newPin)
                        onSetupComplete()
                    } else {
                        // Error mismatch
                        isError = true
                        errorMessage = "PINs do not match. Please try again."
                        scope.launch {
                            delay(1200)
                            firstPin = ""
                            confirmPin = ""
                            isError = false
                            errorMessage = null
                            stage = PinSetupStage.CREATE
                        }
                    }
                }
            }
        }
    }

    fun handleDelete() {
        if (isError) return
        if (stage == PinSetupStage.CREATE) {
            if (firstPin.isNotEmpty()) firstPin = firstPin.dropLast(1)
        } else {
            if (confirmPin.isNotEmpty()) {
                confirmPin = confirmPin.dropLast(1)
            } else {
                // Return to CREATE stage if user deletes all in CONFIRM
                stage = PinSetupStage.CREATE
                firstPin = ""
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(OneUIBackground)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(28.dp))

        // Shield Icon Header
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(OneUISurfaceElevated),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = OneUIBlue,
                modifier = Modifier.size(32.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Animated stage title
        AnimatedContent(
            targetState = stage,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "setup_title"
        ) { targetStage ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = if (targetStage == PinSetupStage.CREATE) "Set 6-Digit PIN" else "Confirm Your PIN",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = OneUITextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("pin_setup_heading")
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (targetStage == PinSetupStage.CREATE)
                        "Choose a secure 6-digit master passcode to lock your sensitive apps"
                    else
                        "Re-enter the 6 digits to verify your master passcode",
                    fontSize = 14.sp,
                    color = OneUITextSecondary,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // 6 Indicator Dots
        PinIndicatorDots(
            pinLength = currentEnteredPin.length,
            maxDigits = 6,
            isError = isError,
            modifier = Modifier.testTag("pin_setup_dots")
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Error message text or helper
        Box(
            modifier = Modifier.height(24.dp),
            contentAlignment = Alignment.Center
        ) {
            if (errorMessage != null) {
                Text(
                    text = errorMessage ?: "",
                    color = OneUIError,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            } else {
                Text(
                    text = "${currentEnteredPin.length} / 6 digits entered",
                    color = OneUITextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Samsung One UI Number Pad
        OneUINumPad(
            onDigitClick = { handleDigit(it) },
            onDeleteClick = { handleDelete() },
            showBiometricButton = false,
            scrambleDigits = false,
            enabled = !isError,
            modifier = Modifier
                .padding(bottom = 16.dp)
                .testTag("setup_numpad")
        )
    }
}
