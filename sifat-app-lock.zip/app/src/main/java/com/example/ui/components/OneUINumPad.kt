package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.OneUIBlue
import com.example.ui.theme.OneUISurfaceElevated
import com.example.ui.theme.OneUISurfaceVariant
import com.example.ui.theme.OneUITextMuted
import com.example.ui.theme.OneUITextPrimary
import com.example.ui.theme.OneUITextSecondary

@Composable
fun OneUINumPad(
    onDigitClick: (String) -> Unit,
    onDeleteClick: () -> Unit,
    onBiometricClick: (() -> Unit)? = null,
    showBiometricButton: Boolean = true,
    scrambleDigits: Boolean = false,
    enabled: Boolean = true,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current

    val digits = remember(scrambleDigits) {
        if (scrambleDigits) {
            (0..9).shuffled()
        } else {
            listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 0)
        }
    }

    // Letters associated with phone keypad digits
    val lettersMap = mapOf(
        1 to "", 2 to "ABC", 3 to "DEF",
        4 to "GHI", 5 to "JKL", 6 to "MNO",
        7 to "PQRS", 8 to "TUV", 9 to "WXYZ",
        0 to "+"
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Rows 1-3 (3x3 grid)
        for (row in 0..2) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (col in 0..2) {
                    val index = row * 3 + col
                    val digit = digits[index]
                    KeypadButton(
                        digit = digit.toString(),
                        subtitle = if (!scrambleDigits) lettersMap[digit] ?: "" else "",
                        enabled = enabled,
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            onDigitClick(digit.toString())
                        }
                    )
                }
            }
        }

        // Bottom row: Biometric / blank, 10th digit, Backspace
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Action button (Left): Biometric icon
            if (showBiometricButton && onBiometricClick != null) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(OneUIBlue.copy(alpha = 0.12f))
                        .clickable(enabled = enabled) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onBiometricClick()
                        }
                        .testTag("biometric_auth_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fingerprint,
                        contentDescription = "Unlock with Fingerprint",
                        tint = OneUIBlue,
                        modifier = Modifier.size(34.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.size(76.dp))
            }

            // 10th Digit (typically 0 or scrambled)
            val lastDigit = digits[9]
            KeypadButton(
                digit = lastDigit.toString(),
                subtitle = if (!scrambleDigits) lettersMap[lastDigit] ?: "" else "",
                enabled = enabled,
                onClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onDigitClick(lastDigit.toString())
                }
            )

            // Delete Backspace button (Right)
            Box(
                modifier = Modifier
                    .size(76.dp)
                    .clip(CircleShape)
                    .background(OneUISurfaceVariant.copy(alpha = 0.5f))
                    .clickable(enabled = enabled) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDeleteClick()
                    }
                    .testTag("pin_delete_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Backspace,
                    contentDescription = "Delete Digit",
                    tint = OneUITextSecondary,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}

@Composable
private fun KeypadButton(
    digit: String,
    subtitle: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(OneUISurfaceElevated)
            .clickable(enabled = enabled, onClick = onClick)
            .testTag("keypad_digit_$digit"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = digit,
                color = if (enabled) OneUITextPrimary else OneUITextMuted,
                fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold
            )
            if (subtitle.isNotEmpty()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = OneUITextMuted,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 1.2.sp
                )
            }
        }
    }
}
